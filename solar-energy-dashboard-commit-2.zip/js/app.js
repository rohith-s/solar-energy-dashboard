/*
 * Solar Energy Dashboard
 * Application bootstrap
 * Version 0.1.0
 */

import { CONFIG } from "./config.js";
import { initRouter, registerRoute } from "./router.js";
import { getItem, setItem } from "./storage.js";
import { formatMonthYear } from "./utils.js";
import * as Dashboard from "../modules/dashboard/dashboard.js";

const THEME_KEY = "theme";

function applyTheme(theme) {
    const root = document.documentElement;

    if (theme === "dark") {
        root.setAttribute("data-theme", "dark");
        return;
    }

    if (theme === "light") {
        root.setAttribute("data-theme", "light");
        return;
    }

    const isDark = window.matchMedia(
        "(prefers-color-scheme: dark)"
    ).matches;

    root.setAttribute("data-theme", isDark ? "dark" : "light");
}

function initializeTheme() {
    const savedTheme = getItem(THEME_KEY, CONFIG.UI.THEME);
    applyTheme(savedTheme);
}

function initializeHeader() {
    const monthElement = document.getElementById("current-month");

    if (monthElement) {
        monthElement.textContent = formatMonthYear(new Date());
    }
}

function initializeNavigation() {
    document.querySelectorAll("[data-route]").forEach((element) => {
        element.addEventListener("click", () => {
            const route = element.dataset.route;

            if (route) {
                window.location.hash = `#/${route}`;
            }
        });
    });
}

function updateNavigation(route) {
    document.querySelectorAll("[data-route]").forEach((element) => {
        const isActive = element.dataset.route === route;
        element.classList.toggle("active", isActive);

        if (isActive) {
            element.setAttribute("aria-current", "page");
        } else {
            element.removeAttribute("aria-current");
        }
    });
}

function initializeSnackbar() {
    const snackbar = document.getElementById("snackbar");

    window.showSnackbar = (message, duration = 3000) => {
        if (!snackbar) {
            return;
        }

        snackbar.textContent = message;
        snackbar.classList.add("is-visible");

        window.clearTimeout(window.__sedSnackbarTimer);

        window.__sedSnackbarTimer = window.setTimeout(() => {
            snackbar.classList.remove("is-visible");
        }, duration);
    };
}

function initializeLoading() {
    const overlay = document.getElementById("loading-overlay");
    const message = document.getElementById("loading-message");

    window.showLoading = (text = "Loading...") => {
        if (!overlay) {
            return;
        }

        if (message) {
            message.textContent = text;
        }

        overlay.classList.remove("hidden");
        overlay.setAttribute("aria-hidden", "false");
    };

    window.hideLoading = () => {
        if (!overlay) {
            return;
        }

        overlay.classList.add("hidden");
        overlay.setAttribute("aria-hidden", "true");
    };
}

function initializeRoutes() {
    registerRoute("dashboard", Dashboard.render, {
        title: "Dashboard | Solar Energy Dashboard"
    });

    registerRoute("reading", () => `
        <div class="page-container">
            <section class="card">
                <div class="empty-state">
                    <div>
                        <span class="material-symbols-outlined">add_circle</span>
                        <h3>Reading module</h3>
                        <p>The reading entry form is the next implementation step.</p>
                    </div>
                </div>
            </section>
        </div>
    `, {
        title: "Reading | Solar Energy Dashboard"
    });

    registerRoute("history", () => `
        <div class="page-container">
            <section class="card">
                <div class="empty-state">
                    <div>
                        <span class="material-symbols-outlined">history</span>
                        <h3>History module</h3>
                        <p>Reading history will be implemented after the data model is finalized.</p>
                    </div>
                </div>
            </section>
        </div>
    `, {
        title: "History | Solar Energy Dashboard"
    });

    registerRoute("analytics", () => `
        <div class="page-container">
            <section class="card">
                <div class="empty-state">
                    <div>
                        <span class="material-symbols-outlined">analytics</span>
                        <h3>Analytics module</h3>
                        <p>Charts and monthly analytics will be implemented after readings are available.</p>
                    </div>
                </div>
            </section>
        </div>
    `, {
        title: "Analytics | Solar Energy Dashboard"
    });

    registerRoute("settings", () => `
        <div class="page-container">
            <section class="card">
                <div class="empty-state">
                    <div>
                        <span class="material-symbols-outlined">settings</span>
                        <h3>Settings module</h3>
                        <p>Application and tariff configuration will be implemented in the Settings module.</p>
                    </div>
                </div>
            </section>
        </div>
    `, {
        title: "Settings | Solar Energy Dashboard"
    });
}

function initialize() {
    console.info(
        `Solar Energy Dashboard v${CONFIG.APP.VERSION}`
    );

    initializeTheme();
    initializeHeader();
    initializeSnackbar();
    initializeLoading();
    initializeNavigation();
    initializeRoutes();

    document.addEventListener("route-rendered", (event) => {
        updateNavigation(event.detail.route);

        if (event.detail.route === "dashboard") {
            Dashboard.init();
        }

        const content = document.getElementById("app-content");

        if (content) {
            content.focus({ preventScroll: true });
        }
    });

    initRouter(document.getElementById("app-content"));

    // Persist a small bootstrap marker. Actual readings will NOT be stored
    // here; Google Sheets will be the shared source of truth.
    setItem("lastAppStart", new Date().toISOString());
}

document.addEventListener("DOMContentLoaded", initialize);
