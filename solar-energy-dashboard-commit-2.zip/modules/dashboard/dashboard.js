/*
 * Solar Energy Dashboard
 * Dashboard module
 * Version 0.1.0
 */

import {
    formatKwh,
    formatMonthYear,
    escapeHtml
} from "../../js/utils.js";

const navigationItems = [
    { route: "reading", icon: "add_circle", label: "Add Reading" },
    { route: "history", icon: "history", label: "View History" },
    { route: "analytics", icon: "analytics", label: "Analytics" }
];

function statCard(title, value, description, icon) {
    return `
        <article class="card stat-card">
            <div class="stat-card-header">
                <span>${escapeHtml(title)}</span>
                <span class="stat-icon material-symbols-outlined">${icon}</span>
            </div>

            <div class="stat-value">
                ${formatKwh(value)}
            </div>

            <div class="stat-description">
                ${escapeHtml(description)}
            </div>
        </article>
    `;
}

function getEmptyDashboard() {
    return {
        solarGenerated: 0,
        gridImport: 0,
        gridExport: 0,
        consumption: 0
    };
}

function renderQuickActions() {
    return navigationItems.map((item) => `
        <button class="quick-action" type="button"
                data-navigate="${escapeHtml(item.route)}">
            <span class="material-symbols-outlined">${item.icon}</span>
            <strong>${escapeHtml(item.label)}</strong>
        </button>
    `).join("");
}

export function render() {
    const data = getEmptyDashboard();
    const currentMonth = formatMonthYear(new Date());

    return `
        <div class="page-container">

            <header class="page-header">
                <div>
                    <p class="eyebrow">Energy overview</p>
                    <h1>Good evening 👋</h1>
                    <p class="page-description">
                        Track your solar generation, grid import and export for
                        ${escapeHtml(currentMonth)}.
                    </p>
                </div>

                <div class="page-header-actions">
                    <button class="btn btn-primary"
                            type="button"
                            data-navigate="reading">
                        <span class="material-symbols-outlined">add</span>
                        Add Reading
                    </button>
                </div>
            </header>

            <section class="kpi-grid" aria-label="Energy summary">
                ${statCard(
                    "Solar Generated",
                    data.solarGenerated,
                    "From inverter readings",
                    "solar_power"
                )}

                ${statCard(
                    "Grid Import",
                    data.gridImport,
                    "Energy consumed from grid",
                    "download"
                )}

                ${statCard(
                    "Grid Export",
                    data.gridExport,
                    "Energy supplied to grid",
                    "upload"
                )}

                ${statCard(
                    "Home Consumption",
                    data.consumption,
                    "Calculated total usage",
                    "home"
                )}
            </section>

            <section class="dashboard-grid">

                <article class="card">
                    <div class="card-body">

                        <div class="section-heading">
                            <div>
                                <h2>Energy trend</h2>
                                <p>Daily generation will appear after readings are entered.</p>
                            </div>
                        </div>

                        <div class="empty-state">
                            <div>
                                <span class="material-symbols-outlined">bar_chart</span>
                                <h3>No readings yet</h3>
                                <p>
                                    Add your first reading to start building
                                    your monthly energy history.
                                </p>
                            </div>
                        </div>

                    </div>
                </article>

                <article class="card">
                    <div class="card-body">

                        <div class="section-heading">
                            <div>
                                <h2>System status</h2>
                                <p>Application health</p>
                            </div>
                        </div>

                        <div class="status-row">
                            <span class="status-label">Local application</span>
                            <span class="status-pill success">
                                <span class="material-symbols-outlined">check_circle</span>
                                Ready
                            </span>
                        </div>

                        <div class="status-row">
                            <span class="status-label">Google Sheets</span>
                            <span class="status-pill warning">
                                Not connected
                            </span>
                        </div>

                        <div class="status-row">
                            <span class="status-label">Current month</span>
                            <span class="status-value">
                                ${escapeHtml(currentMonth)}
                            </span>
                        </div>

                    </div>
                </article>

            </section>

            <section class="card">
                <div class="card-body">

                    <div class="section-heading">
                        <div>
                            <h2>Quick actions</h2>
                            <p>Common actions for your energy tracking.</p>
                        </div>
                    </div>

                    <div class="quick-actions">
                        ${renderQuickActions()}
                    </div>

                </div>
            </section>

        </div>
    `;
}

export function init() {
    document
        .querySelectorAll("[data-navigate]")
        .forEach((element) => {
            element.addEventListener("click", () => {
                const route = element.dataset.navigate;
                window.location.hash = `#/${route}`;
            });
        });
}
